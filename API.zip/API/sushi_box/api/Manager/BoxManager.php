<?php
class BoxManager {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function findAll() {
        try {
            $boxes = $this->pdo->query("SELECT * FROM boxes")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($boxes as &$box) {
                $box = $this->addBoxDetails($box);
            }

            return $boxes;
        } catch (PDOException $e) {
            error_log("BoxManager findAll error: " . $e->getMessage());
            return [];
        }
    }

    public function findById($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM boxes WHERE id = ?");
            $stmt->execute([$id]);
            $box = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($box) {
                $box = $this->addBoxDetails($box);
            }

            return $box;
        } catch (PDOException $e) {
            error_log("BoxManager findById error: " . $e->getMessage());
            return null;
        }
    }

    private function addBoxDetails($box) {
        try {
            $box['price'] = round($box['price'], 2);

            // Foods
            $stmt = $this->pdo->prepare("
                SELECT f.name, CAST(bf.quantity AS UNSIGNED) AS quantity
                FROM box_foods bf
                JOIN foods f ON bf.food_id = f.id
                WHERE bf.box_id = :id
            ");
            $stmt->execute(['id' => $box['id']]);
            $box['foods'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Flavors
            $stmt = $this->pdo->prepare("
                SELECT fl.name
                FROM box_flavors bf
                JOIN flavors fl ON bf.flavor_id = fl.id
                WHERE bf.box_id = :id
            ");
            $stmt->execute(['id' => $box['id']]);
            $box['flavors'] = array_column($stmt->fetchAll(), 'name');

            return $box;
        } catch (PDOException $e) {
            error_log("BoxManager addBoxDetails error: " . $e->getMessage());
            return $box; // Retourner la box sans les détails supplémentaires
        }
    }
}
?>