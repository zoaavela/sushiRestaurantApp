<?php
require_once __DIR__ . '/../config/database.php';

class UserManager {
    private $pdo;

    public function __construct() {
        $db = new Database();
        $this->pdo = $db->getConnection();
    }
    
    // --- NOUVEAU: Fonction de lecture avec conversion de type ---
    private function executeFetchQuery($sql, $params) {
        try {
            $query = $this->pdo->prepare($sql);
            $query->execute($params);
            $user = $query->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                // SÉCURITÉ : Conversion des types pour Angular (nb_commande et depense_totale)
                $user['nb_commande'] = (int)($user['nb_commande'] ?? 0);
                $user['depense_totale'] = (float)($user['depense_totale'] ?? 0.0);
            }
            return $user;
        } catch (PDOException $e) {
            return null;
        }
    }
    // --- FIN NOUVEAU BLOC ---


    /**
     * Creation utilisateur (Inscription)
     */
    public function createUser($firstname, $lastname, $email, $password, $status = null, $age = null, $ville = null, $code_postal = null) {
        try {
            $existingUser = $this->getUserByEmail($email);
            if ($existingUser) {
                return false;
            }
            
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            
            $sql = "INSERT INTO users (firstname, lastname, email, password, status, age, ville, code_postal, created_at) 
                    VALUES (:firstname, :lastname, :email, :password, :status, :age, :ville, :code_postal, NOW())";
            
            $query = $this->pdo->prepare($sql);
            
            return $query->execute([
                ':firstname' => $firstname,
                ':lastname' => $lastname,
                ':email' => $email,
                ':password' => $passwordHash,
                ':status' => $status,
                ':age' => $age,
                ':ville' => $ville,
                ':code_postal' => $code_postal
            ]);
            
        } catch (PDOException $e) {
            return false;
        }
    }

    public function getUserByEmail($email) {
        try {
            $sql = "SELECT * FROM users WHERE email = :email";
            $query = $this->pdo->prepare($sql);
            $query->execute([':email' => $email]);
            return $query->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return null;
        }
    }
    
    // MODIFIÉ: Utilise la nouvelle méthode pour garantir la conversion des stats
    public function getUserById($id) {
        return $this->executeFetchQuery("SELECT * FROM users WHERE id = :id", [':id' => $id]);
    }

    // MODIFIÉ: Utilise la nouvelle méthode pour garantir la conversion des stats
    public function getUserByToken($token){
        return $this->executeFetchQuery("SELECT * FROM users WHERE api_token = :token", [':token' => $token]);
    }

    public function updateToken($id, $token){
        try {
            $sql = "UPDATE users SET api_token = :token, derniere_connexion = NOW() WHERE id = :id";
            $query = $this->pdo->prepare($sql);
            return $query->execute([':id' => $id, ':token' => $token]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Mise à jour du profil utilisateur (VERSION SÉCURISÉE)
     */
    public function updateUser($id, $data) {
        try {
            $fields = [];
            $params = [':id' => $id];

            // Construction dynamique de la requête
            if (isset($data['firstname'])) { $fields[] = 'firstname = :firstname'; $params[':firstname'] = $data['firstname']; }
            if (isset($data['lastname'])) { $fields[] = 'lastname = :lastname'; $params[':lastname'] = $data['lastname']; }
            if (isset($data['email'])) { $fields[] = 'email = :email'; $params[':email'] = $data['email']; }
            
            // Les champs optionnels doivent utiliser array_key_exists pour accepter null
            if (array_key_exists('age', $data)) { $fields[] = 'age = :age'; $params[':age'] = $data['age'] ?? null; }
            if (array_key_exists('ville', $data)) { $fields[] = 'ville = :ville'; $params[':ville'] = $data['ville'] ?? null; }
            if (array_key_exists('code_postal', $data)) { $fields[] = 'code_postal = :code_postal'; $params[':code_postal'] = $data['code_postal'] ?? null; }

            if (!empty($data['password'])) {
                $fields[] = "password = :password";
                $params[':password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            
            if (empty($fields)) {
                return true; 
            }

            $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = :id";
            $stmt = $this->pdo->prepare($sql);
            
            return $stmt->execute($params);

        } catch (PDOException $e) { 
            return false; 
        }
    }
}