<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

try {
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../Manager/UserManager.php';

    $token = null;
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $token = str_replace('Bearer ', '', $_SERVER['HTTP_AUTHORIZATION']);
    } elseif (function_exists('getallheaders')) {
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? null;
        if ($authHeader) $token = str_replace('Bearer ', '', $authHeader);
    }

    if (!$token) throw new Exception('Token manquant', 401);

    $userManager = new UserManager();
    $user = $userManager->getUserByToken($token);

    if (!$user || $user['role'] !== 'admin') {
        throw new Exception('Accès interdit', 403);
    }

    $db = new Database();
    $pdo = $db->getConnection();

    function getResult($pdo, $sql, $params = []) {
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (Exception $e) { return false; }
    }

    // KPIS
    $stmt = getResult($pdo, "SELECT SUM(total_price) FROM orders WHERE status != 'cancelled'");
    $ca = $stmt ? ($stmt->fetchColumn() ?: 0) : 0;

    $stmt = getResult($pdo, "SELECT COUNT(*) FROM orders");
    $totalOrders = $stmt ? ($stmt->fetchColumn() ?: 0) : 0;

    $avgBasket = ($totalOrders > 0) ? $ca / $totalOrders : 0;

    $stmt = getResult($pdo, "SELECT COUNT(DISTINCT user_id) FROM orders");
    $uniqueClients = $stmt ? ($stmt->fetchColumn() ?: 0) : 0;

    // TOP PRODUITS (Correction : Ajout de b.image)
    $sqlTop = "SELECT b.name, b.price, b.image, SUM(oi.quantity) as total_sold
               FROM order_items oi
               JOIN boxes b ON oi.box_id = b.id
               JOIN orders o ON oi.order_id = o.id
               WHERE o.status != 'cancelled'
               GROUP BY b.id, b.name, b.price, b.image
               ORDER BY total_sold DESC LIMIT 5";
    $stmt = getResult($pdo, $sqlTop);
    $topProducts = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];

    // GRAPHIQUES
    $sqlEvo = "SELECT DATE(created_at) as date, SUM(total_price) as daily_ca 
               FROM orders WHERE status != 'cancelled' 
               GROUP BY DATE(created_at) ORDER BY date ASC LIMIT 30";
    $stmt = getResult($pdo, $sqlEvo);
    $evolutionCA = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];

    $sqlDays = "SELECT DAYNAME(created_at) as day_name, DAYOFWEEK(created_at) as day_idx, COUNT(*) as count 
                FROM orders WHERE status != 'cancelled' 
                GROUP BY day_idx, day_name ORDER BY day_idx ASC";
    $stmt = getResult($pdo, $sqlDays);
    $weeklyTraffic = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];

    ob_end_clean();
    echo json_encode([
        'kpi' => [
            'ca' => round((float)$ca, 2),
            'orders' => (int)$totalOrders,
            'avg_basket' => round((float)$avgBasket, 2),
            'clients' => (int)$uniqueClients
        ],
        'top_products' => $topProducts,
        'charts' => [
            'revenue_timeline' => $evolutionCA,
            'weekly_traffic' => $weeklyTraffic
        ]
    ]);

} catch (Exception $e) {
    ob_end_clean();
    http_response_code(500);
    echo json_encode(['error' => 'Erreur Serveur', 'details' => $e->getMessage()]);
}
?>