<?php
class Database {
    private $host = "localhost";
    private $db_name = "sushi_box";
    private $username = "root";
    private $password = "";
    public $pdo;

    public function getConnection() {
        $this->pdo = null;
        try {
            $this->pdo = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name, 
                $this->username, 
                $this->password
            );
            $this->pdo->exec("set names utf8");
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            // Ne pas afficher l'erreur directement, la logger
            error_log("Connection error: " . $exception->getMessage());
            return null;
        }
        return $this->pdo;
    }
}