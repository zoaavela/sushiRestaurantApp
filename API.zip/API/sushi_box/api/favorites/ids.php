<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

try {
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../Manager/UserManager.php';

    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? null;
    $token = $authHeader ? str_replace('Bearer ', '', $authHeader) : null;

    // Si pas connecté, on renvoie une liste vide sans erreur
    if (!$token) {
        ob_end_clean();
        echo json_encode([]);
        exit;
    }

    $userManager = new UserManager();
    $user = $userManager->getUserByToken($token);

    if (!$user) {
        ob_end_clean();
        echo json_encode([]);
        exit;
    }

    $db = new Database();
    $pdo = $db->getConnection();

    $stmt = $pdo->prepare("SELECT box_id FROM favorites WHERE user_id = ?");
    $stmt->execute([$user['id']]);
    // FETCH_COLUMN renvoie un tableau simple d'IDs [1, 5, 8]
    $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

    ob_end_clean();
    echo json_encode($ids);

} catch (Exception $e) {
    ob_end_clean();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>