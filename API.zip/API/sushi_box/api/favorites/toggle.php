<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

try {
    // 2. INCLUSIONS
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../Manager/UserManager.php';

    // 3. AUTHENTIFICATION
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? null;
    $token = $authHeader ? str_replace('Bearer ', '', $authHeader) : null;

    if (!$token) throw new Exception('Non connecté', 401);

    $userManager = new UserManager();
    $user = $userManager->getUserByToken($token);

    if (!$user) throw new Exception('Token invalide', 401);

    // 4. RECUPERATION DONNÉES
    $input = json_decode(file_get_contents('php://input'), true);
    $boxId = $input['box_id'] ?? null;

    if (!$boxId) throw new Exception('ID box manquant', 400);

    // 5. LOGIQUE FAVORIS (Toggle)
    $db = new Database();
    $pdo = $db->getConnection();

    // Vérifie si déjà liké
    $stmt = $pdo->prepare("SELECT 1 FROM favorites WHERE user_id = ? AND box_id = ?");
    $stmt->execute([$user['id'], $boxId]);
    $exists = $stmt->fetch();

    if ($exists) {
        // Supprimer
        $del = $pdo->prepare("DELETE FROM favorites WHERE user_id = ? AND box_id = ?");
        $del->execute([$user['id'], $boxId]);
        $action = 'removed';
    } else {
        // Ajouter
        $add = $pdo->prepare("INSERT INTO favorites (user_id, box_id) VALUES (?, ?)");
        $add->execute([$user['id'], $boxId]);
        $action = 'added';
    }

    ob_end_clean();
    echo json_encode(['success' => true, 'status' => $action]);

} catch (Exception $e) {
    ob_end_clean();
    http_response_code($e->getCode() ?: 500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>