<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { 
    ob_end_clean();
    http_response_code(200); 
    exit; 
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../Manager/UserManager.php';

try {
    // 1. Récupération du Token
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? null;
    $token = $authHeader ? str_replace('Bearer ', '', $authHeader) : null;

    if (!$token) throw new Exception('Non authentifié', 401);

    $userManager = new UserManager();
    $user = $userManager->getUserByToken($token);

    if (!$user) throw new Exception('Utilisateur invalide', 401);

    // 2. Requête SQL pour récupérer commandes ET items
    $db = new Database();
    $pdo = $db->getConnection();

    // On fait une jointure pour tout avoir d'un coup
    $sql = "SELECT 
                o.id as order_id, o.total_price, o.status, o.created_at,
                oi.quantity, oi.unit_price,
                b.name as box_name, b.image
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            JOIN boxes b ON oi.box_id = b.id
            WHERE o.user_id = :user_id
            ORDER BY o.created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['user_id' => $user['id']]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 3. Regroupement des données (car SQL renvoie une ligne par item)
    $orders = [];
    foreach ($rows as $row) {
        $id = $row['order_id'];
        
        // Si la commande n'existe pas encore dans le tableau, on l'initie
        if (!isset($orders[$id])) {
            $orders[$id] = [
                'id' => $id,
                'date' => $row['created_at'],
                'total' => $row['total_price'],
                'status' => $row['status'],
                'items' => []
            ];
        }

        // On ajoute l'item à la commande
        $orders[$id]['items'][] = [
            'box_name' => $row['box_name'],
            'quantity' => $row['quantity'],
            'price' => $row['unit_price'],
            'image' => $row['image']
        ];
    }

    // On transforme le tableau associatif en tableau indexé pour le JSON
    ob_end_clean();
    echo json_encode(array_values($orders));

} catch (Exception $e) {
    ob_end_clean();
    http_response_code($e->getCode() ?: 500);
    echo json_encode(['error' => $e->getMessage()]);
}