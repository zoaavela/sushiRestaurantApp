<?php
ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); http_response_code(200); exit; }

try {
    require_once __DIR__ . '/../config/database.php';
    $db = new Database();
    $pdo = $db->getConnection();

    function safeQuery($pdo, $sql) {
        try { return $pdo->query($sql); } catch (Exception $e) { return false; }
    }

    // 1. LE PODIUM (Avec b.image)
    $sqlTop = "SELECT b.name, b.image, SUM(oi.quantity) as total_sold
               FROM order_items oi
               JOIN boxes b ON oi.box_id = b.id
               JOIN orders o ON oi.order_id = o.id
               WHERE o.status != 'cancelled'
               GROUP BY b.id, b.name, b.image
               ORDER BY total_sold DESC LIMIT 3";
    $topProducts = safeQuery($pdo, $sqlTop)->fetchAll(PDO::FETCH_ASSOC);

    // 2. COMPTEUR GLOBAL
    $sqlPieces = "SELECT SUM(COALESCE(b.pieces, 12) * oi.quantity) 
                  FROM order_items oi 
                  JOIN boxes b ON oi.box_id = b.id
                  JOIN orders o ON oi.order_id = o.id
                  WHERE o.status != 'cancelled'";
    $globalPieces = safeQuery($pdo, $sqlPieces)->fetchColumn() ?: 0;

    // 3. CARTE
    $sqlAdresses = "SELECT adresse FROM orders WHERE status != 'cancelled' AND adresse IS NOT NULL";
    $stmt = safeQuery($pdo, $sqlAdresses);
    $adresses = ($stmt !== false) ? $stmt->fetchAll(PDO::FETCH_COLUMN) : [];

    $citiesCoords = [
        'Paris' => [48.8566, 2.3522],
        'Lyon' => [45.7640, 4.8357],
        'Marseille' => [43.2965, 5.3698],
        'Bordeaux' => [44.8378, -0.5792],
        'Lille' => [50.6292, 3.0573],
        'Toulouse' => [43.6047, 1.4442],
        'Nantes' => [47.2184, -1.5536],
        'Strasbourg' => [48.5734, 7.7521],
        'Nice' => [43.7102, 7.2620],
        'Montpellier' => [43.6107, 3.8767]
    ];

    $mapData = [];
    foreach ($citiesCoords as $city => $coords) {
        $count = 0;
        foreach ($adresses as $addr) {
            if (empty($addr)) continue;
            if (stripos($addr, $city) !== false) $count++;
        }
        if ($count > 0) {
            $mapData[] = ['city' => $city, 'lat' => $coords[0], 'lng' => $coords[1], 'count' => $count];
        }
    }
    
    // Donnée test si vide
    if (empty($mapData)) {
        $mapData[] = ['city' => 'Paris (QG)', 'lat' => 48.8566, 'lng' => 2.3522, 'count' => 1];
    }

    ob_end_clean();
    echo json_encode([
        'top_products' => $topProducts,
        'global_pieces' => (int)$globalPieces,
        'map_data' => $mapData
    ]);

} catch (Exception $e) {
    ob_end_clean(); http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
}
?>