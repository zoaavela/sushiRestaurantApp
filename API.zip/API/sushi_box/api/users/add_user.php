<?php
// 1. BUFFERING ET CONFIG
ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

try {
    // 3. RECUPERATION DATA
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (empty($data)) {
        throw new Exception("Aucune donnée reçue (JSON invalide ?)");
    }

    // 4. LOGIQUE METIER
    if (!file_exists(__DIR__ . '/../Manager/UserManager.php')) {
        throw new Exception("Fichier UserManager introuvable");
    }
    require_once __DIR__ . '/../Manager/UserManager.php';
    
    $userManager = new UserManager();
    $status = $data['status'] ?? null;
    
    // Nouveaux champs
    $age = $data['age'] ?? null;
    $ville = $data['ville'] ?? null;
    $code_postal = $data['code_postal'] ?? null;

    // Appel au manager avec les 8 arguments (les 3 nouveaux sont null si non fournis)
    $success = $userManager->createUser(
        $data['firstname'] ?? '',
        $data['lastname'] ?? '',
        $data['email'] ?? '',
        $data['password'] ?? '',
        $status,
        $age,
        $ville,
        $code_postal
    );

    // 5. NETTOYAGE ET REPONSE
    ob_end_clean();

    if ($success) {
        http_response_code(201);
        $json = json_encode(['success' => true, 'message' => 'Compte créé']);
    } else {
        http_response_code(400); 
        $json = json_encode(['error' => 'Email déjà utilisé ou erreur base de données']);
    }

    if ($json === false) {
        echo '{"error":"Erreur encodage JSON"}';
    } else {
        echo $json;
    }

} catch (Exception $e) {
    ob_end_clean();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>