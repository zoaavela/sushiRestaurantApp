<?php
// 1. CONFIGURATION CORS (INDISPENSABLE)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");

// Gestion du Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');

// Désactiver l'affichage des erreurs HTML pour ne pas casser le JSON
ini_set('display_errors', 0);
error_reporting(E_ALL);

try {
    $content = file_get_contents('php://input');
    $data = json_decode($content, true);

    // Vérification basique
    if (!isset($data['email']) || !isset($data['password']) || empty($data['email']) || empty($data['password'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Email et mot de passe requis']);
        exit;
    }

    require_once __DIR__ . '/../Manager/UserManager.php';
    $userManager = new UserManager();

    // getUserByEmail renvoie déjà SELECT * (toutes les colonnes)
    $user = $userManager->getUserByEmail($data['email']); 

    if (!$user || !password_verify($data['password'], $user['password'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Email ou mot de passe incorrect']);
        exit;
    }

    $token = bin2hex(random_bytes(32));

    // La méthode updateToken met à jour le jeton.
    // DANS LE CODE STABLE : nous allons faire en sorte que updateToken renvoie l'utilisateur complet mis à jour.
    $userManager->updateToken($user['id'], $token);
    
    // Pour être certain que l'objet renvoyé est complet et à jour (avec la dernière_connexion)
    // On rappelle la BDD pour récupérer l'objet complet.
    $updatedUser = $userManager->getUserById($user['id']);

    if ($updatedUser) {
        // SUCCÈS : On retire le mot de passe et on renvoie l'objet COMPLET
        unset($updatedUser['password']); 

        echo json_encode([
            'message' => 'Connection successful',
            'token' => $token,
            'user' => $updatedUser // Renvoie toutes les données (profil, stats, etc.)
        ]);
    } else {
        throw new Exception('Erreur interne lors de la mise à jour du token');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur: ' . $e->getMessage()]);
}
?>