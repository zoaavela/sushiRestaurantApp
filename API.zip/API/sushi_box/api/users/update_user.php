<?php
// DANS api/users/update_user.php

// 1. BUFFERING ET CONFIG
ob_start();
ini_set('display_errors', 0); 
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); // Ajout de GET
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

try {
    // 2. AUTHENTIFICATION PAR JETON
    $headers = getallheaders();
    $token = str_replace('Bearer ', '', $headers['Authorization'] ?? $headers['authorization'] ?? '');

    require_once __DIR__ . '/../Manager/UserManager.php';
    $userManager = new UserManager();
    $user = $userManager->getUserByToken($token);

    if (!$user) {
        throw new Exception("Non autorisé. Jeton manquant ou invalide.", 401);
    }
    
    // NOUVEAU BLOC : GESTION DE LA LECTURE (GET) POUR LE REFRESH DU PROFIL
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // En mode GET, on renvoie simplement le profil mis à jour
        $updatedUser = $userManager->getUserById($user['id']);
        
        // Sécurité
        unset($updatedUser['password']); 
        
        ob_end_clean();
        http_response_code(200);
        // On renvoie l'objet utilisateur COMPLET pour mettre à jour l'AuthService
        echo json_encode($updatedUser);
        exit;
    }


    // --- SUITE : Exécution en mode POST (Mise à jour du profil) ---

    // 3. RECUPERATION DES DONNEES (ce qui vient d'Angular)
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data)) {
        // En POST, si le body est vide, c'est une erreur 
        throw new Exception("Aucune donnée de mise à jour reçue.");
    }
    
    // 4. MISE À JOUR EN BASE DE DONNÉES
    $success = $userManager->updateUser($user['id'], $data);

    // 5. REPONSE
    ob_end_clean(); 

    if ($success) {
        // Re-fetch user pour renvoyer le profil mis à jour à Angular
        $updatedUser = $userManager->getUserById($user['id']);
        
        unset($updatedUser['password']); 
        
        http_response_code(200);
        echo json_encode(['success' => true, 'message' => 'Profil mis à jour.', 'user' => $updatedUser]);
    } else {
        http_response_code(400); 
        echo json_encode(['error' => "Erreur lors de la mise à jour du profil. L'email est peut-être déjà utilisé."]);
    }
    
} catch (Exception $e) {
    ob_end_clean();
    http_response_code($e->getCode() ?: 500);
    echo json_encode(['error' => 'Erreur fatale: ' . $e->getMessage()]); 
}
?>