ob_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

try {
    require_once '../config/database.php';
    require_once '../Manager/UserManager.php';

    // Récupérer le token
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';

    if (empty($authHeader) || !str_contains($authHeader, 'Bearer ')) {
        throw new Exception('Authorization header missing', 401);
    }

    $token = str_replace('Bearer ', '', $authHeader);

    // Vérifier l'utilisateur
    $userManager = new UserManager();
    $user = $userManager->getUserByToken($token);

    if (!$user) {
        throw new Exception('Invalid token', 401);
    }

    // Récupérer les données de la commande
    // $content = file_get_contents('php://input');
    // $data = json_decode($content, true);

    // if (!$data) {
    //     throw new Exception('Invalid JSON data', 400);
    // }

    // Ici tu devras créer une table "orders" et "order_items" plus tard
    // Pour le moment, on retourne un succès simulé

    ob_end_clean();
    http_response_code(201);
    echo json_encode([
        'message' => 'Commande créée avec succès',
        'commande_id' => rand(1000, 9999),
        'user_id' => $user['id'],
        'statut' => 'en_attente'
    ]);

} catch (Exception $e) {
    ob_end_clean();
    http_response_code($e->getCode() ?: 500);
    echo json_encode(['error' => $e->getMessage()]);
}